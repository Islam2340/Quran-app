package ru.quran.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){if(document.querySelector('#pn')?.classList.contains('on')){X();return 'panel'}return 'main'})()", result -> {
            if ("\"panel\"".equals(result)) return;
            new AlertDialog.Builder(this).setTitle("Выход")
                .setMessage("Вы действительно хотите закрыть приложение?")
                .setNegativeButton("Отмена", (d,w) -> d.dismiss())
                .setPositiveButton("Выйти", (d,w) -> finish()).show();
        });
    }
}
